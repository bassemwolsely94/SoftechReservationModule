from django.apps import AppConfig


class DemandConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.demand'
    verbose_name = 'محرك الطلب والمبيعات الضائعة'
