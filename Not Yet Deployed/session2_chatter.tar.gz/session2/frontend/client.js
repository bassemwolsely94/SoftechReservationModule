import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})

// Attach JWT token to every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Auto-refresh on 401
api.interceptors.response.use(
  res => res,
  async err => {
    const original = err.config
    if (err.response?.status === 401 && !original._retry) {
      original._retry = true
      const refresh = localStorage.getItem('refresh_token')
      if (refresh) {
        try {
          const { data } = await axios.post('/api/auth/refresh/', { refresh })
          localStorage.setItem('access_token', data.access)
          original.headers.Authorization = `Bearer ${data.access}`
          return api(original)
        } catch {
          localStorage.clear()
          window.location.href = '/login'
        }
      }
    }
    return Promise.reject(err)
  }
)

export default api

// ── Auth ──────────────────────────────────────────────────────────────────────

export const authApi = {
  login: (username, password) => api.post('/auth/login/', { username, password }),
  me: () => api.get('/auth/me/'),
}

// ── Reservations ──────────────────────────────────────────────────────────────

export const reservationsApi = {
  list:         (params) => api.get('/reservations/', { params }),
  get:          (id) => api.get(`/reservations/${id}/`),
  create:       (data) => api.post('/reservations/', data),
  update:       (id, data) => api.patch(`/reservations/${id}/`, data),
  changeStatus: (id, status, note = '') =>
    api.post(`/reservations/${id}/change-status/`, { status, note }),
  dashboard:    (params) => api.get('/reservations/dashboard/', { params }),

  // Chatter
  activities:   (id) => api.get(`/reservations/${id}/activities/`),
  logActivity:  (id, formData) =>
    api.post(`/reservations/${id}/log/`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
}

// ── Customers ─────────────────────────────────────────────────────────────────

export const customersApi = {
  list:        (params) => api.get('/customers/', { params }),
  get:         (id) => api.get(`/customers/${id}/`),
  create:      (data) => api.post('/customers/', data),
  update:      (id, data) => api.patch(`/customers/${id}/`, data),
  purchases:   (id) => api.get(`/customers/${id}/purchases/`),
  reservations:(id) => api.get(`/customers/${id}/reservations/`),
  addNote:     (id, note) => api.post(`/customers/${id}/notes/`, { note }),
}

// ── Items ─────────────────────────────────────────────────────────────────────

export const itemsApi = {
  list:  (params) => api.get('/items/', { params }),
  get:   (id) => api.get(`/items/${id}/`),
  stock: (id) => api.get(`/items/${id}/stock/`),
}

// ── Branches ──────────────────────────────────────────────────────────────────

export const branchesApi = {
  list: () => api.get('/branches/'),
}

// ── Sync ──────────────────────────────────────────────────────────────────────

export const syncApi = {
  status:  () => api.get('/sync/status/'),
  trigger: (full = false) => api.post('/sync/trigger/', { full }),
  logs:    () => api.get('/sync/logs/'),
}

// ── Dashboard ─────────────────────────────────────────────────────────────────

export const dashboardApi = {
  summary: (params) => api.get('/dashboard/summary/', { params }),
}

// ── Notifications ─────────────────────────────────────────────────────────────

export const notificationsApi = {
  list:       () => api.get('/notifications/'),
  unreadCount:() => api.get('/notifications/unread-count/'),
  markRead:   (id) => api.post(`/notifications/${id}/read/`),
  markAllRead:() => api.post('/notifications/mark-all-read/'),
}

// ── Transfers ─────────────────────────────────────────────────────────────────

export const transfersApi = {
  list:       (params) => api.get('/transfers/', { params }),
  get:        (id) => api.get(`/transfers/${id}/`),
  create:     (data) => api.post('/transfers/', data),
  respond:    (id, data) => api.post(`/transfers/${id}/respond/`, data),
  fulfill:    (id, data) => api.post(`/transfers/${id}/fulfill/`, data),
  cancel:     (id) => api.post(`/transfers/${id}/cancel/`),
  itemStock:  (itemId) => api.get('/transfers/item_stock/', { params: { item_id: itemId } }),
  flagged:    () => api.get('/transfers/flagged/'),
  analytics:  () => api.get('/transfers/analytics/'),
}
