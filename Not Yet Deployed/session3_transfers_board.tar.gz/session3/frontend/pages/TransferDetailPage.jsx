import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { transfersApi, reservationsApi } from '../api/client'
import useAuthStore from '../store/authStore'
import { formatDistanceToNow, format } from 'date-fns'
import { ar } from 'date-fns/locale'

// ── Constants ─────────────────────────────────────────────────────────────────

const TRANSFER_STATUSES = {
  draft:     { label: 'مسودة',              bg: '#f9fafb',   text: '#6b7280', dot: '#9ca3af' },
  sent:      { label: 'بانتظار الرد',       bg: '#fefce8',   text: '#92400e', dot: '#f59e0b' },
  accepted:  { label: 'مقبول بالكامل',     bg: '#f0fdf4',   text: '#166534', dot: '#10b981' },
  partial:   { label: 'مقبول جزئياً',      bg: '#eff6ff',   text: '#1e40af', dot: '#3b82f6' },
  rejected:  { label: 'مرفوض',             bg: '#fef2f2',   text: '#991b1b', dot: '#ef4444' },
  fulfilled: { label: 'تم التنفيذ',         bg: '#f0f9f4',   text: '#1B6B3A', dot: '#1B6B3A' },
  cancelled: { label: 'ملغي',              bg: '#f9fafb',   text: '#9ca3af', dot: '#d1d5db' },
}

const REJECTION_REASONS = [
  { value: 'insufficient_stock',  label: 'مخزون غير كافٍ' },
  { value: 'reserved_customers',  label: 'مخزون محجوز لعملاء الفرع' },
  { value: 'item_on_order',       label: 'الصنف قيد الأوردر' },
  { value: 'other',               label: 'أخرى' },
]

// ── Helpers ───────────────────────────────────────────────────────────────────

function timeAgo(dt) {
  if (!dt) return '—'
  try { return formatDistanceToNow(new Date(dt), { locale: ar, addSuffix: true }) } catch { return '' }
}

function fmtDateTime(d) {
  if (!d) return '—'
  try { return format(new Date(d), 'd MMM yyyy — HH:mm', { locale: ar }) } catch { return d }
}

function TransferStatusBadge({ status }) {
  const s = TRANSFER_STATUSES[status] || TRANSFER_STATUSES.draft
  return (
    <span
      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-semibold"
      style={{ background: s.bg, color: s.text, border: `1px solid ${s.dot}33` }}
    >
      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: s.dot }} />
      {s.label}
    </span>
  )
}

// ── Stock widget ──────────────────────────────────────────────────────────────

function StockTable({ stockByBranch, sourceId, requestingId }) {
  if (!stockByBranch?.length) return (
    <div className="text-xs text-gray-400 text-center py-4">لا توجد بيانات مخزون</div>
  )
  const total = stockByBranch.reduce((s, b) => s + b.quantity, 0)
  return (
    <div className="space-y-1.5">
      {stockByBranch.map(s => {
        const isSource = s.branch_id === sourceId
        const isRequesting = s.branch_id === requestingId
        const pct = total > 0 ? Math.round((s.quantity / total) * 100) : 0
        return (
          <div
            key={s.branch_id}
            className={`rounded-lg p-2.5 ${
              isSource ? 'bg-green-50 border border-green-200' :
              isRequesting ? 'bg-brand-50 border border-brand-200' :
              'bg-gray-50'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5">
                <span className={`text-xs font-medium ${
                  isSource ? 'text-green-700' : isRequesting ? 'text-brand-700' : 'text-gray-600'
                }`}>
                  {s.branch_name}
                </span>
                {isSource && <span className="text-xs bg-green-100 text-green-600 px-1 rounded">مصدر</span>}
                {isRequesting && <span className="text-xs bg-brand-100 text-brand-600 px-1 rounded">طالب</span>}
              </div>
              <span className={`text-xs font-bold tabular-nums ${
                s.quantity > 10 ? 'text-green-700' : s.quantity > 0 ? 'text-orange-600' : 'text-red-500'
              }`}>
                {s.quantity > 0 ? s.quantity.toFixed(1) : 'نفد'}
              </span>
            </div>
            <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${
                  s.quantity > 10 ? 'bg-green-400' : s.quantity > 0 ? 'bg-orange-400' : 'bg-red-300'
                }`}
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── Source Branch Reservations (conflict check) ───────────────────────────────

function ConflictChecker({ sourceBranchReservations }) {
  if (!sourceBranchReservations?.length) return (
    <div className="text-xs text-green-600 bg-green-50 border border-green-200 rounded-lg px-3 py-2">
      ✅ لا توجد حجوزات نشطة لهذا الصنف بالفرع المصدر
    </div>
  )
  return (
    <div className="bg-orange-50 border border-orange-200 rounded-xl p-3">
      <div className="text-xs font-bold text-orange-700 mb-2">
        ⚠ حجوزات نشطة للصنف بالفرع المصدر ({sourceBranchReservations.length})
      </div>
      <div className="space-y-1">
        {sourceBranchReservations.map(r => (
          <div key={r.id} className="flex items-center justify-between text-xs text-orange-800 bg-white rounded-lg px-2 py-1.5">
            <span>{r.customer_name}</span>
            <div className="flex items-center gap-2">
              <span className="tabular-nums">{r.quantity} وحدة</span>
              <span className="bg-orange-100 px-1.5 py-0.5 rounded">{r.status_label}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Respond Panel ─────────────────────────────────────────────────────────────

function RespondPanel({ transfer, onResponded }) {
  const qc = useQueryClient()
  const [action, setAction] = useState('') // 'accept' | 'partial' | 'reject'
  const [qtyApproved, setQtyApproved] = useState('')
  const [rejectReason, setRejectReason] = useState('')
  const [rejectText, setRejectText] = useState('')
  const [responseNote, setResponseNote] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async () => {
    if (!action) { setError('اختر نوع الرد'); return }
    if (action === 'partial' && (!qtyApproved || Number(qtyApproved) <= 0)) {
      setError('أدخل الكمية المعتمدة'); return
    }
    if (action === 'reject' && !rejectReason) {
      setError('اختر سبب الرفض'); return
    }
    setSubmitting(true); setError('')
    try {
      await transfersApi.respond(transfer.id, {
        action,
        quantity_approved: qtyApproved || undefined,
        rejection_reason: rejectReason || undefined,
        rejection_reason_text: rejectText,
        response_note: responseNote,
      })
      qc.invalidateQueries(['transfer', String(transfer.id)])
      qc.invalidateQueries(['transfers'])
      onResponded?.()
    } catch (e) {
      const d = e.response?.data
      setError(typeof d === 'object' ? Object.values(d).flat().join(' ') : 'حدث خطأ')
    } finally { setSubmitting(false) }
  }

  return (
    <div className="bg-white rounded-2xl border-2 border-yellow-300 p-5 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-lg">↩️</span>
        <h3 className="font-bold text-gray-900 text-sm">الرد على طلب التحويل</h3>
      </div>

      {/* Action selector */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        {[
          { key: 'accept',  label: 'قبول كامل',   icon: '✅', color: 'green' },
          { key: 'partial', label: 'قبول جزئي',   icon: '⚠️', color: 'blue' },
          { key: 'reject',  label: 'رفض',          icon: '❌', color: 'red' },
        ].map(opt => (
          <button
            key={opt.key}
            onClick={() => { setAction(opt.key); setError('') }}
            className={`flex flex-col items-center gap-1 p-3 rounded-xl border-2 transition-all text-xs font-semibold ${
              action === opt.key
                ? opt.color === 'green' ? 'border-green-400 bg-green-50 text-green-700'
                  : opt.color === 'blue' ? 'border-blue-400 bg-blue-50 text-blue-700'
                  : 'border-red-400 bg-red-50 text-red-700'
                : 'border-gray-200 bg-white text-gray-500 hover:border-gray-300'
            }`}
          >
            <span className="text-xl">{opt.icon}</span>
            {opt.label}
          </button>
        ))}
      </div>

      {/* Partial: qty field */}
      {action === 'partial' && (
        <div className="mb-3">
          <label className="label text-xs">الكمية المعتمدة</label>
          <input
            type="number" min="0.001" step="0.001"
            className="input-field"
            placeholder={`الطلب: ${transfer.quantity_needed} وحدة`}
            value={qtyApproved}
            onChange={e => setQtyApproved(e.target.value)}
          />
        </div>
      )}

      {/* Reject: reason */}
      {action === 'reject' && (
        <div className="mb-3 space-y-2">
          <div>
            <label className="label text-xs">سبب الرفض *</label>
            <select className="input-field" value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}>
              <option value="">اختر السبب...</option>
              {REJECTION_REASONS.map(r => (
                <option key={r.value} value={r.value}>{r.label}</option>
              ))}
            </select>
          </div>
          {rejectReason === 'other' && (
            <textarea rows={2} className="input-field resize-none text-sm"
              placeholder="اشرح السبب بالتفصيل..."
              value={rejectText}
              onChange={e => setRejectText(e.target.value)} />
          )}
        </div>
      )}

      {/* Response note */}
      {action && (
        <div className="mb-4">
          <label className="label text-xs">ملاحظة للفرع الطالب (اختياري)</label>
          <textarea rows={2} className="input-field resize-none text-sm"
            placeholder="أي معلومات إضافية..."
            value={responseNote}
            onChange={e => setResponseNote(e.target.value)} />
        </div>
      )}

      {error && (
        <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mb-3">
          {error}
        </div>
      )}

      {action && (
        <button
          onClick={handleSubmit}
          disabled={submitting}
          className={`w-full font-bold py-2.5 rounded-xl text-sm transition-colors disabled:opacity-50 ${
            action === 'reject'
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : action === 'accept'
              ? 'bg-green-600 hover:bg-green-700 text-white'
              : 'bg-blue-600 hover:bg-blue-700 text-white'
          }`}
        >
          {submitting ? 'جارٍ الإرسال...' : 'إرسال الرد'}
        </button>
      )}
    </div>
  )
}

// ── Fulfill Panel ─────────────────────────────────────────────────────────────

function FulfillPanel({ transfer, onFulfilled }) {
  const qc = useQueryClient()
  const [reservationId, setReservationId] = useState(transfer.linked_reservation || '')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  const handleFulfill = async () => {
    setSubmitting(true); setError('')
    try {
      await transfersApi.fulfill(transfer.id, {
        fulfillment_reservation: reservationId || null,
      })
      qc.invalidateQueries(['transfer', String(transfer.id)])
      qc.invalidateQueries(['transfers'])
      onFulfilled?.()
    } catch (e) {
      setError(e.response?.data?.detail || 'حدث خطأ')
    } finally { setSubmitting(false) }
  }

  return (
    <div className="bg-white rounded-2xl border-2 border-green-300 p-5 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-lg">✅</span>
        <h3 className="font-bold text-gray-900 text-sm">تأكيد استلام وتنفيذ التحويل</h3>
      </div>
      <p className="text-xs text-gray-500 mb-4 leading-relaxed">
        اضغط هنا بعد استلام المخزون المحوَّل وتسجيل المبيعة. سيُسجَّل هذا في سجل المشتريات.
      </p>

      <div className="mb-4">
        <label className="label text-xs">رقم الحجز المرتبط (اختياري)</label>
        <input
          type="number" className="input-field"
          placeholder="مثال: 145"
          value={reservationId}
          onChange={e => setReservationId(e.target.value)}
        />
        <div className="text-xs text-gray-400 mt-1">
          إذا كان هذا التحويل لخدمة حجز بعينه، أدخل رقمه لربطهما.
        </div>
      </div>

      {error && (
        <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mb-3">
          {error}
        </div>
      )}

      <button
        onClick={handleFulfill}
        disabled={submitting}
        className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl text-sm transition-colors disabled:opacity-50"
      >
        {submitting ? 'جارٍ التسجيل...' : '✅ تأكيد التنفيذ'}
      </button>
    </div>
  )
}

// ── Timeline ──────────────────────────────────────────────────────────────────

function TransferTimeline({ transfer }) {
  const events = []

  events.push({
    icon: '📤',
    label: 'تم إنشاء الطلب',
    by: transfer.requested_by_name,
    at: transfer.created_at,
    note: transfer.request_note,
    color: 'bg-gray-400',
  })

  if (transfer.responded_at) {
    const statusIcons = { accepted: '✅', partial: '⚠️', rejected: '❌' }
    events.push({
      icon: statusIcons[transfer.status] || '↩️',
      label: TRANSFER_STATUSES[transfer.status]?.label || transfer.status,
      by: transfer.responded_by_name,
      at: transfer.responded_at,
      note: transfer.response_note,
      color: transfer.status === 'accepted' ? 'bg-green-500'
           : transfer.status === 'partial'   ? 'bg-blue-500'
           : transfer.status === 'rejected'  ? 'bg-red-500'
           : 'bg-gray-400',
    })
  }

  if (transfer.fulfilled_at) {
    events.push({
      icon: '🏁',
      label: 'تم التنفيذ',
      by: null,
      at: transfer.fulfilled_at,
      note: transfer.fulfillment_reservation
        ? `مرتبط بالحجز #${transfer.fulfillment_reservation}`
        : null,
      color: 'bg-brand-600',
    })
  }

  if (transfer.flagged_no_sale) {
    events.push({
      icon: '⚠',
      label: 'تحذير: لا مبيعات مسجلة بعد 14 يوم',
      by: 'النظام',
      at: null,
      note: null,
      color: 'bg-red-500',
    })
  }

  return (
    <div className="space-y-0">
      {events.map((ev, i) => (
        <div key={i} className="flex gap-3">
          <div className="flex flex-col items-center">
            <div className={`w-7 h-7 rounded-full ${ev.color} text-white flex items-center justify-center text-sm flex-shrink-0`}>
              {ev.icon}
            </div>
            {i < events.length - 1 && (
              <div className="w-px flex-1 bg-gray-200 my-1" />
            )}
          </div>
          <div className="pb-4 flex-1">
            <div className="font-semibold text-gray-800 text-sm">{ev.label}</div>
            {ev.by && <div className="text-xs text-gray-500 mt-0.5">بواسطة: {ev.by}</div>}
            {ev.at && (
              <div className="text-xs text-gray-400 mt-0.5">{fmtDateTime(ev.at)}</div>
            )}
            {ev.note && (
              <div className="text-xs text-gray-600 mt-1 bg-gray-50 rounded-lg px-2 py-1.5 border border-gray-100">
                {ev.note}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function TransferDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const { user } = useAuthStore()

  const { data: transfer, isLoading, isError } = useQuery({
    queryKey: ['transfer', id],
    queryFn: () => transfersApi.get(id).then(r => r.data),
    refetchInterval: 30_000,
  })

  const cancelMutation = useMutation({
    mutationFn: () => transfersApi.cancel(id),
    onSuccess: () => {
      qc.invalidateQueries(['transfer', id])
      qc.invalidateQueries(['transfers'])
    },
  })

  if (isLoading) return (
    <div className="p-8 animate-pulse" dir="rtl">
      <div className="h-8 w-64 bg-gray-200 rounded-xl mb-6" />
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {[1, 2, 3].map(i => <div key={i} className="h-32 bg-gray-100 rounded-xl" />)}
        </div>
        <div className="h-96 bg-gray-100 rounded-xl" />
      </div>
    </div>
  )

  if (isError || !transfer) return (
    <div className="p-8 text-center" dir="rtl">
      <div className="text-5xl mb-3">😕</div>
      <div className="text-gray-600">لم يتم العثور على طلب التحويل</div>
      <button onClick={() => navigate('/transfers')} className="btn-secondary mt-4">← العودة</button>
    </div>
  )

  const userRole = user?.role || 'viewer'
  const userBranchId = user?.branch_id

  // Can this user respond? Must be source branch staff or admin
  const canRespond = (
    transfer.status === 'sent' &&
    (userRole === 'admin' ||
     (userBranchId === transfer.source_branch && ['pharmacist', 'salesperson', 'call_center'].includes(userRole)))
  )

  // Can this user fulfill? Must be requesting branch staff or admin
  const canFulfill = (
    ['accepted', 'partial'].includes(transfer.status) &&
    (userRole === 'admin' || userBranchId === transfer.requesting_branch)
  )

  // Can cancel? Requesting branch or admin, not yet responded
  const canCancel = (
    ['sent', 'draft'].includes(transfer.status) &&
    (userRole === 'admin' || userBranchId === transfer.requesting_branch)
  )

  const st = TRANSFER_STATUSES[transfer.status] || TRANSFER_STATUSES.draft

  return (
    <div className="min-h-full bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center gap-4 flex-wrap">
          <button onClick={() => navigate('/transfers')}
            className="text-gray-400 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100 transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl font-black text-gray-900">طلب تحويل #{transfer.id}</h1>
              <TransferStatusBadge status={transfer.status} />
              {transfer.flagged_no_sale && (
                <span className="badge bg-red-100 text-red-700">⚠ غير مُصرَّف</span>
              )}
            </div>
            <div className="text-xs text-gray-400 mt-0.5 flex items-center gap-2 flex-wrap">
              <span>بواسطة: {transfer.requested_by_name}</span>
              <span>·</span>
              <span>{transfer.requested_by_branch}</span>
              <span>·</span>
              <span>{timeAgo(transfer.created_at)}</span>
            </div>
          </div>

          {canCancel && (
            <button
              onClick={() => {
                if (window.confirm('هل تريد إلغاء هذا الطلب؟')) cancelMutation.mutate()
              }}
              className="btn-danger text-sm"
              disabled={cancelMutation.isPending}
            >
              {cancelMutation.isPending ? 'جارٍ...' : 'إلغاء الطلب'}
            </button>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="max-w-6xl mx-auto px-6 py-6 grid lg:grid-cols-3 gap-6">

        {/* Left: main content */}
        <div className="lg:col-span-2 flex flex-col gap-5">

          {/* Transfer summary card */}
          <div className="card">
            <h3 className="font-bold text-gray-400 text-xs uppercase tracking-wide mb-4">تفاصيل الطلب</h3>
            <div className="grid grid-cols-2 gap-4">
              {/* Item */}
              <div className="col-span-2 bg-gray-50 rounded-xl p-3">
                <div className="text-xs text-gray-400 mb-1">الصنف</div>
                <div className="font-bold text-gray-900">{transfer.item_name}</div>
                {transfer.item_scientific && (
                  <div className="text-xs text-gray-400 italic">{transfer.item_scientific}</div>
                )}
                {transfer.item_softech_id && (
                  <div className="text-xs text-blue-500 font-mono mt-0.5">كود: {transfer.item_softech_id}</div>
                )}
              </div>

              {/* Branch flow */}
              <div className="bg-brand-50 rounded-xl p-3 border border-brand-100">
                <div className="text-xs text-brand-500 mb-1">الفرع الطالب</div>
                <div className="font-bold text-brand-800">{transfer.requesting_branch_name}</div>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <div className="text-xs text-gray-400 mb-1">الفرع المصدر</div>
                <div className="font-bold text-gray-800">{transfer.source_branch_name}</div>
              </div>

              {/* Quantities */}
              <div>
                <div className="text-xs text-gray-400 mb-1">الكمية المطلوبة</div>
                <div className="text-2xl font-black text-gray-900 tabular-nums">
                  {transfer.quantity_needed}
                  <span className="text-sm font-normal text-gray-400 mr-1">وحدة</span>
                </div>
              </div>
              {transfer.quantity_approved && (
                <div>
                  <div className="text-xs text-gray-400 mb-1">الكمية المعتمدة</div>
                  <div className={`text-2xl font-black tabular-nums ${
                    Number(transfer.quantity_approved) === Number(transfer.quantity_needed)
                      ? 'text-green-700' : 'text-blue-700'
                  }`}>
                    {transfer.quantity_approved}
                    <span className="text-sm font-normal text-gray-400 mr-1">وحدة</span>
                  </div>
                </div>
              )}
            </div>

            {/* Notes */}
            {transfer.request_note && (
              <div className="mt-4 bg-yellow-50 border border-yellow-100 rounded-xl p-3">
                <div className="text-xs text-yellow-700 font-semibold mb-1">ملاحظة الطلب</div>
                <p className="text-sm text-gray-700">{transfer.request_note}</p>
              </div>
            )}

            {/* Rejection info */}
            {transfer.status === 'rejected' && (
              <div className="mt-4 bg-red-50 border border-red-200 rounded-xl p-3">
                <div className="text-xs text-red-700 font-bold mb-1">سبب الرفض</div>
                <div className="text-sm text-red-800">{transfer.rejection_reason_label}</div>
                {transfer.rejection_reason_text && (
                  <div className="text-xs text-red-600 mt-1">{transfer.rejection_reason_text}</div>
                )}
                {transfer.response_note && (
                  <div className="text-xs text-red-500 mt-1 italic">{transfer.response_note}</div>
                )}
              </div>
            )}

            {/* Response note for accepted/partial */}
            {['accepted', 'partial'].includes(transfer.status) && transfer.response_note && (
              <div className="mt-4 bg-green-50 border border-green-100 rounded-xl p-3">
                <div className="text-xs text-green-700 font-semibold mb-1">ملاحظة الرد</div>
                <p className="text-sm text-gray-700">{transfer.response_note}</p>
              </div>
            )}
          </div>

          {/* Source branch conflict check */}
          {['sent', 'draft'].includes(transfer.status) && (
            <div className="card">
              <h3 className="font-bold text-gray-400 text-xs uppercase tracking-wide mb-3">
                فحص التعارض — حجوزات الفرع المصدر
              </h3>
              <ConflictChecker sourceBranchReservations={transfer.source_branch_reservations} />
            </div>
          )}

          {/* Respond panel — source branch only */}
          {canRespond && (
            <RespondPanel
              transfer={transfer}
              onResponded={() => {
                qc.invalidateQueries(['transfer', id])
                qc.invalidateQueries(['transfers'])
              }}
            />
          )}

          {/* Fulfill panel — requesting branch only */}
          {canFulfill && (
            <FulfillPanel
              transfer={transfer}
              onFulfilled={() => {
                qc.invalidateQueries(['transfer', id])
                qc.invalidateQueries(['transfers'])
              }}
            />
          )}
        </div>

        {/* Right sidebar */}
        <div className="flex flex-col gap-4">

          {/* Timeline */}
          <div className="card">
            <h3 className="font-bold text-gray-400 text-xs uppercase tracking-wide mb-4">المسار الزمني</h3>
            <TransferTimeline transfer={transfer} />
          </div>

          {/* Stock by branch */}
          <div className="card">
            <h3 className="font-bold text-gray-400 text-xs uppercase tracking-wide mb-3">المخزون بالفروع</h3>
            <StockTable
              stockByBranch={transfer.stock_by_branch}
              sourceId={transfer.source_branch}
              requestingId={transfer.requesting_branch}
            />
          </div>

          {/* Linked reservation */}
          {transfer.linked_reservation_id && (
            <div className="card">
              <h3 className="font-bold text-gray-400 text-xs uppercase tracking-wide mb-2">الحجز المرتبط</h3>
              <button
                onClick={() => navigate(`/reservations/${transfer.linked_reservation_id}`)}
                className="w-full text-right bg-brand-50 border border-brand-200 rounded-xl p-3 hover:bg-brand-100 transition-colors"
              >
                <div className="text-sm font-bold text-brand-700">حجز #{transfer.linked_reservation_id}</div>
                <div className="text-xs text-brand-500 mt-0.5">عرض تفاصيل الحجز ←</div>
              </button>
            </div>
          )}

          {/* Metadata */}
          <div className="card">
            <h3 className="font-bold text-gray-400 text-xs uppercase tracking-wide mb-3">بيانات الطلب</h3>
            <div className="space-y-2 text-xs">
              <div>
                <span className="text-gray-400">طُلب بواسطة: </span>
                <span className="text-gray-700 font-medium">{transfer.requested_by_name}</span>
              </div>
              {transfer.responded_by_name && (
                <div>
                  <span className="text-gray-400">تم الرد بواسطة: </span>
                  <span className="text-gray-700 font-medium">{transfer.responded_by_name}</span>
                </div>
              )}
              <div>
                <span className="text-gray-400">تاريخ الطلب: </span>
                <span className="text-gray-700">{fmtDateTime(transfer.created_at)}</span>
              </div>
              {transfer.responded_at && (
                <div>
                  <span className="text-gray-400">تاريخ الرد: </span>
                  <span className="text-gray-700">{fmtDateTime(transfer.responded_at)}</span>
                </div>
              )}
              {transfer.fulfilled_at && (
                <div>
                  <span className="text-gray-400">تاريخ التنفيذ: </span>
                  <span className="text-gray-700">{fmtDateTime(transfer.fulfilled_at)}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
