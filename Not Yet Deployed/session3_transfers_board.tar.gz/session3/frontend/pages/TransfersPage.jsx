import { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { transfersApi, branchesApi, itemsApi } from '../api/client'
import useAuthStore from '../store/authStore'
import { formatDistanceToNow, format } from 'date-fns'
import { ar } from 'date-fns/locale'

// ── Constants ─────────────────────────────────────────────────────────────────

const TRANSFER_STATUSES = {
  draft:     { label: 'مسودة',              bg: 'bg-gray-100',    text: 'text-gray-600',    dot: '#9ca3af' },
  sent:      { label: 'بانتظار الرد',       bg: 'bg-yellow-100',  text: 'text-yellow-700',  dot: '#f59e0b' },
  accepted:  { label: 'مقبول بالكامل',     bg: 'bg-green-100',   text: 'text-green-700',   dot: '#10b981' },
  partial:   { label: 'مقبول جزئياً',      bg: 'bg-blue-100',    text: 'text-blue-700',    dot: '#3b82f6' },
  rejected:  { label: 'مرفوض',             bg: 'bg-red-100',     text: 'text-red-700',     dot: '#ef4444' },
  fulfilled: { label: 'تم التنفيذ',         bg: 'bg-brand-100',   text: 'text-brand-700',   dot: '#1B6B3A' },
  cancelled: { label: 'ملغي',              bg: 'bg-gray-100',    text: 'text-gray-400',    dot: '#d1d5db' },
}

const KANBAN_COLUMNS = [
  { key: 'sent',      ...TRANSFER_STATUSES.sent },
  { key: 'accepted',  ...TRANSFER_STATUSES.accepted },
  { key: 'partial',   ...TRANSFER_STATUSES.partial },
  { key: 'rejected',  ...TRANSFER_STATUSES.rejected },
  { key: 'fulfilled', ...TRANSFER_STATUSES.fulfilled },
]

const REJECTION_REASONS = [
  { value: 'insufficient_stock',  label: 'مخزون غير كافٍ' },
  { value: 'reserved_customers',  label: 'مخزون محجوز لعملاء الفرع' },
  { value: 'item_on_order',       label: 'الصنف قيد الأوردر' },
  { value: 'other',               label: 'أخرى' },
]

// ── Helpers ───────────────────────────────────────────────────────────────────

function timeAgo(dt) {
  if (!dt) return '—'
  try { return formatDistanceToNow(new Date(dt), { locale: ar, addSuffix: true }) } catch { return '' }
}

function fmtDate(d) {
  if (!d) return '—'
  try { return format(new Date(d), 'd MMM yyyy — HH:mm', { locale: ar }) } catch { return d }
}

function TransferBadge({ status }) {
  const s = TRANSFER_STATUSES[status] || TRANSFER_STATUSES.draft
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${s.bg} ${s.text}`}>
      <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: s.dot }} />
      {s.label}
    </span>
  )
}

// ── Stock Lookup Panel ────────────────────────────────────────────────────────

function StockLookupPanel({ onCreateRequest, userBranchId, branches }) {
  const [itemSearch, setItemSearch] = useState('')
  const [selectedItem, setSelectedItem] = useState(null)
  const [showResults, setShowResults] = useState(false)

  const { data: searchResults, isLoading: searching } = useQuery({
    queryKey: ['item-search', itemSearch],
    queryFn: () => itemsApi.list({ search: itemSearch, page_size: 10 }).then(r => r.data.results || r.data),
    enabled: itemSearch.length >= 2,
  })

  const { data: stockData, isLoading: loadingStock } = useQuery({
    queryKey: ['transfer-item-stock', selectedItem?.id],
    queryFn: () => transfersApi.itemStock(selectedItem.id).then(r => r.data),
    enabled: !!selectedItem?.id,
  })

  const totalQty = stockData?.stock_by_branch?.reduce((s, b) => s + b.quantity_on_hand, 0) || 0

  return (
    <div className="card h-full flex flex-col">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-lg">🔍</span>
        <h3 className="font-bold text-gray-800 text-sm">بحث المخزون + طلب تحويل</h3>
      </div>

      {/* Item search */}
      <div className="relative mb-4">
        <input
          className="input-field pr-9"
          placeholder="ابحث عن صنف بالاسم أو الكود..."
          value={itemSearch}
          onChange={e => {
            setItemSearch(e.target.value)
            setShowResults(true)
            if (!e.target.value) { setSelectedItem(null) }
          }}
        />
        <span className="absolute right-3 top-2.5 text-gray-400 text-sm">🔍</span>

        {/* Dropdown results */}
        {showResults && itemSearch.length >= 2 && (searchResults?.length > 0) && (
          <div className="absolute z-20 w-full bg-white border border-gray-200 rounded-xl shadow-lg mt-1 max-h-56 overflow-y-auto">
            {searching && <div className="px-4 py-3 text-xs text-gray-400">جارٍ البحث...</div>}
            {(searchResults || []).map(item => (
              <button
                key={item.id}
                className="w-full text-right px-4 py-2.5 hover:bg-brand-50 transition-colors border-b border-gray-50 last:border-0"
                onClick={() => {
                  setSelectedItem(item)
                  setItemSearch(item.name)
                  setShowResults(false)
                }}
              >
                <div className="text-sm font-medium text-gray-800">{item.name}</div>
                {item.name_scientific && (
                  <div className="text-xs text-gray-400 italic">{item.name_scientific}</div>
                )}
                <div className="text-xs text-blue-500 font-mono">كود: {item.softech_id}</div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Stock data */}
      {loadingStock && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-gray-400 text-sm animate-pulse">جارٍ تحميل بيانات المخزون...</div>
        </div>
      )}

      {stockData && !loadingStock && (
        <div className="flex-1 flex flex-col gap-3 overflow-y-auto">
          {/* Item header */}
          <div className="bg-brand-50 border border-brand-100 rounded-xl p-3">
            <div className="font-bold text-brand-800 text-sm">{stockData.item.name}</div>
            {stockData.item.name_scientific && (
              <div className="text-xs text-brand-600 italic">{stockData.item.name_scientific}</div>
            )}
            <div className="text-xs text-brand-500 font-mono mt-0.5">كود: {stockData.item.softech_id}</div>
            <div className="text-xs text-brand-700 font-semibold mt-1">
              الإجمالي: {totalQty.toFixed(1)} وحدة
            </div>
          </div>

          {/* Stock by branch */}
          <div className="space-y-1.5">
            <div className="text-xs text-gray-400 font-medium px-1">المخزون بالفروع</div>
            {(stockData.stock_by_branch || []).map(s => {
              const isMyBranch = s.branch_id === userBranchId
              const barPct = totalQty > 0 ? Math.round((s.quantity_on_hand / totalQty) * 100) : 0
              return (
                <div
                  key={s.branch_id}
                  className={`rounded-lg p-2.5 ${isMyBranch ? 'bg-brand-50 border border-brand-200' : 'bg-gray-50'}`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5">
                      {isMyBranch && <span className="text-xs text-brand-600 font-bold">●</span>}
                      <span className={`text-xs font-medium ${isMyBranch ? 'text-brand-700' : 'text-gray-600'}`}>
                        {s.branch_name}
                      </span>
                      {s.active_reservations > 0 && (
                        <span className="text-xs bg-orange-100 text-orange-600 px-1 rounded">
                          {s.active_reservations} حجز
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold tabular-nums ${
                        s.quantity_on_hand > 10 ? 'text-green-700' :
                        s.quantity_on_hand > 0  ? 'text-orange-600' : 'text-red-500'
                      }`}>
                        {s.quantity_on_hand > 0 ? s.quantity_on_hand.toFixed(1) : 'نفد'}
                      </span>
                      {/* Request transfer button — only shown for other branches with stock */}
                      {!isMyBranch && s.quantity_on_hand > 0 && (
                        <button
                          onClick={() => onCreateRequest({
                            item: stockData.item,
                            sourceBranchId: s.branch_id,
                            sourceBranchName: s.branch_name,
                            availableQty: s.quantity_on_hand,
                          })}
                          className="text-xs bg-brand-600 text-white px-2 py-0.5 rounded-lg hover:bg-brand-700 transition-colors"
                        >
                          طلب تحويل
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        s.quantity_on_hand > 10 ? 'bg-green-400' :
                        s.quantity_on_hand > 0  ? 'bg-orange-400' : 'bg-red-300'
                      }`}
                      style={{ width: `${barPct}%` }}
                    />
                  </div>
                </div>
              )
            })}
          </div>

          {/* Active transfers for this item */}
          {stockData.active_transfer_requests?.length > 0 && (
            <div>
              <div className="text-xs text-gray-400 font-medium px-1 mb-1">
                طلبات التحويل الحالية لهذا الصنف
              </div>
              {stockData.active_transfer_requests.map(t => (
                <div key={t.id} className="bg-yellow-50 border border-yellow-100 rounded-lg p-2 mb-1 text-xs">
                  <span className="font-medium text-yellow-800">طلب #{t.id}</span>
                  <span className="text-yellow-600 mx-1">—</span>
                  <span className="text-yellow-700">{t['requesting_branch__name_ar']}</span>
                  <span className="text-yellow-400 mx-1">←</span>
                  <span className="text-yellow-700">{t['source_branch__name_ar']}</span>
                  <span className="text-yellow-500 mr-2">({t.quantity_needed} وحدة)</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {!selectedItem && !loadingStock && (
        <div className="flex-1 flex flex-col items-center justify-center text-center py-8">
          <div className="text-4xl mb-3">📦</div>
          <div className="text-sm text-gray-400">ابحث عن صنف لعرض المخزون</div>
          <div className="text-xs text-gray-300 mt-1">ستظهر هنا الكميات بجميع الفروع</div>
        </div>
      )}
    </div>
  )
}

// ── Create Transfer Modal ─────────────────────────────────────────────────────

function CreateTransferModal({ prefill, branches, userBranchId, onClose, onCreated }) {
  const [form, setForm] = useState({
    requesting_branch: userBranchId || '',
    source_branch: prefill?.sourceBranchId || '',
    item_id: prefill?.item?.id || '',
    item_name: prefill?.item?.name || '',
    quantity_needed: '',
    request_note: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async () => {
    if (!form.quantity_needed || Number(form.quantity_needed) <= 0) {
      setError('يرجى إدخال كمية صحيحة'); return
    }
    setSubmitting(true); setError('')
    try {
      await transfersApi.create({
        requesting_branch: form.requesting_branch,
        source_branch: form.source_branch,
        item: form.item_id,
        quantity_needed: form.quantity_needed,
        request_note: form.request_note,
      })
      onCreated()
      onClose()
    } catch (e) {
      const data = e.response?.data
      if (typeof data === 'object') {
        setError(Object.values(data).flat().join(' '))
      } else {
        setError('حدث خطأ، يرجى المحاولة مجدداً')
      }
    } finally { setSubmitting(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-base font-bold text-gray-900">🔀 طلب تحويل مخزون جديد</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700 text-xl leading-none">✕</button>
        </div>

        <div className="space-y-4">
          {/* Item (pre-filled and locked if coming from stock panel) */}
          <div>
            <label className="label">الصنف</label>
            {prefill?.item ? (
              <div className="bg-brand-50 border border-brand-200 rounded-lg px-3 py-2">
                <div className="text-sm font-semibold text-brand-800">{prefill.item.name}</div>
                <div className="text-xs text-brand-500 font-mono">كود: {prefill.item.softech_id}</div>
              </div>
            ) : (
              <input className="input-field" placeholder="معرّف الصنف"
                value={form.item_id}
                onChange={e => setForm(f => ({ ...f, item_id: e.target.value }))} />
            )}
          </div>

          {/* Source branch */}
          <div>
            <label className="label">الفرع المصدر (يمتلك المخزون)</label>
            {prefill?.sourceBranchId ? (
              <div className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2">
                <div className="text-sm font-semibold text-gray-700">{prefill.sourceBranchName}</div>
                <div className="text-xs text-green-600 mt-0.5">متاح: {prefill.availableQty?.toFixed(1)} وحدة</div>
              </div>
            ) : (
              <select className="input-field" value={form.source_branch}
                onChange={e => setForm(f => ({ ...f, source_branch: e.target.value }))}>
                <option value="">اختر الفرع المصدر</option>
                {(branches || [])
                  .filter(b => b.id !== Number(form.requesting_branch))
                  .map(b => <option key={b.id} value={b.id}>{b.name_ar || b.name}</option>)}
              </select>
            )}
          </div>

          {/* Requesting branch */}
          <div>
            <label className="label">الفرع الطالب</label>
            <select className="input-field" value={form.requesting_branch}
              onChange={e => setForm(f => ({ ...f, requesting_branch: e.target.value }))}>
              <option value="">اختر الفرع</option>
              {(branches || []).map(b => <option key={b.id} value={b.id}>{b.name_ar || b.name}</option>)}
            </select>
          </div>

          {/* Quantity */}
          <div>
            <label className="label">الكمية المطلوبة</label>
            <input type="number" min="0.001" step="0.001" className="input-field"
              placeholder="مثال: 10"
              value={form.quantity_needed}
              onChange={e => setForm(f => ({ ...f, quantity_needed: e.target.value }))} />
            {prefill?.availableQty && (
              <div className="text-xs text-gray-400 mt-1">
                الحد الأقصى المتاح: {prefill.availableQty.toFixed(1)} وحدة
              </div>
            )}
          </div>

          {/* Note */}
          <div>
            <label className="label">ملاحظة (اختياري)</label>
            <textarea rows={2} className="input-field resize-none"
              placeholder="سبب الطلب أو تفاصيل إضافية..."
              value={form.request_note}
              onChange={e => setForm(f => ({ ...f, request_note: e.target.value }))} />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg px-3 py-2">
              {error}
            </div>
          )}
        </div>

        <div className="flex gap-2 mt-6">
          <button onClick={handleSubmit} disabled={submitting}
            className="btn-primary flex-1 disabled:opacity-50">
            {submitting ? 'جارٍ الإرسال...' : '📤 إرسال الطلب'}
          </button>
          <button onClick={onClose} className="btn-secondary px-4">إلغاء</button>
        </div>
      </div>
    </div>
  )
}

// ── Transfer Card (Kanban) ────────────────────────────────────────────────────

function TransferCard({ transfer, onClick }) {
  const { flagged_no_sale, status } = transfer
  return (
    <div
      onClick={() => onClick(transfer)}
      className={`bg-white rounded-xl border p-3 cursor-pointer hover:shadow-md transition-all duration-150 ${
        flagged_no_sale ? 'border-red-300 bg-red-50/30' : 'border-gray-100 hover:border-gray-200'
      }`}
    >
      {/* Item */}
      <div className="font-semibold text-gray-900 text-sm leading-tight mb-0.5">
        {transfer.item_name}
      </div>
      {transfer.item_softech_id && (
        <div className="text-xs text-gray-400 font-mono mb-2">كود: {transfer.item_softech_id}</div>
      )}

      {/* Branch flow */}
      <div className="flex items-center gap-1 text-xs text-gray-600 mb-2 flex-wrap">
        <span className="bg-brand-50 text-brand-700 px-1.5 py-0.5 rounded font-medium">
          {transfer.requesting_branch_name}
        </span>
        <span className="text-gray-400">←</span>
        <span className="bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">
          {transfer.source_branch_name}
        </span>
      </div>

      {/* Qty */}
      <div className="flex items-center justify-between text-xs">
        <span className="text-gray-500">
          {transfer.quantity_approved
            ? <span>{transfer.quantity_approved} <span className="text-gray-300">/ {transfer.quantity_needed}</span></span>
            : <span>{transfer.quantity_needed} وحدة</span>
          }
        </span>
        {flagged_no_sale && (
          <span className="text-red-600 font-bold">⚠ غير مُصرَّف</span>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-50">
        <span className="text-xs text-gray-400">{transfer.requested_by_name}</span>
        <span className="text-xs text-gray-300">{timeAgo(transfer.created_at)}</span>
      </div>
    </div>
  )
}

// ── Kanban Board ──────────────────────────────────────────────────────────────

function KanbanBoard({ transfers, onCardClick }) {
  return (
    <div className="flex gap-3 overflow-x-auto pb-4" style={{ minHeight: 400 }}>
      {KANBAN_COLUMNS.map(col => {
        const cards = transfers.filter(t =>
          col.key === 'rejected'
            ? t.status === 'rejected' || t.status === 'cancelled'
            : t.status === col.key
        )
        return (
          <div key={col.key} style={{ minWidth: 260, flex: '0 0 270px' }}>
            {/* Column header */}
            <div
              className="flex items-center justify-between px-3 py-2.5 rounded-t-xl text-sm font-semibold sticky top-0 z-10"
              style={{
                background: col.bg.replace('bg-', '').includes('brand')
                  ? '#f0f9f4' : col.bg === 'bg-yellow-100' ? '#fefce8'
                  : col.bg === 'bg-green-100' ? '#f0fdf4'
                  : col.bg === 'bg-blue-100' ? '#eff6ff'
                  : col.bg === 'bg-red-100' ? '#fef2f2'
                  : '#f9fafb',
                color: col.dot,
                borderBottom: `2px solid ${col.dot}`,
              }}
            >
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full" style={{ background: col.dot }} />
                {col.label}
              </div>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-white/60">
                {cards.length}
              </span>
            </div>

            {/* Cards */}
            <div className="flex flex-col gap-2 p-2 bg-gray-50/60 rounded-b-xl min-h-24">
              {cards.length === 0 && (
                <div className="text-center py-6 text-gray-300 text-xs">لا يوجد</div>
              )}
              {cards.map(t => (
                <TransferCard key={t.id} transfer={t} onClick={onCardClick} />
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── List View ─────────────────────────────────────────────────────────────────

function ListView({ transfers, onRowClick }) {
  if (transfers.length === 0) return (
    <div className="card text-center py-12">
      <div className="text-4xl mb-3">🔀</div>
      <div className="text-gray-500 font-medium">لا توجد طلبات تحويل</div>
    </div>
  )
  return (
    <div className="card p-0 overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 border-b border-gray-100">
          <tr>
            <th className="text-right px-4 py-3 font-semibold text-gray-500 text-xs">#</th>
            <th className="text-right px-4 py-3 font-semibold text-gray-500 text-xs">الصنف</th>
            <th className="text-right px-4 py-3 font-semibold text-gray-500 text-xs">من ← إلى</th>
            <th className="text-right px-4 py-3 font-semibold text-gray-500 text-xs">الكمية</th>
            <th className="text-right px-4 py-3 font-semibold text-gray-500 text-xs">الحالة</th>
            <th className="text-right px-4 py-3 font-semibold text-gray-500 text-xs">طُلب بواسطة</th>
            <th className="text-right px-4 py-3 font-semibold text-gray-500 text-xs">تاريخ الطلب</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {transfers.map(t => (
            <tr
              key={t.id}
              onClick={() => onRowClick(t)}
              className={`cursor-pointer transition-colors hover:bg-brand-50 ${
                t.flagged_no_sale ? 'bg-red-50/40' : ''
              }`}
            >
              <td className="px-4 py-3 text-gray-400 font-mono text-xs">{t.id}</td>
              <td className="px-4 py-3">
                <div className="font-medium text-gray-800">{t.item_name}</div>
                <div className="text-xs text-gray-400 font-mono">{t.item_softech_id}</div>
              </td>
              <td className="px-4 py-3">
                <div className="flex items-center gap-1.5 text-xs flex-wrap">
                  <span className="bg-brand-50 text-brand-700 px-1.5 py-0.5 rounded font-medium">
                    {t.requesting_branch_name}
                  </span>
                  <span className="text-gray-400">←</span>
                  <span className="bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">
                    {t.source_branch_name}
                  </span>
                </div>
              </td>
              <td className="px-4 py-3 text-sm tabular-nums">
                {t.quantity_approved
                  ? <span className="text-green-700 font-semibold">{t.quantity_approved}</span>
                  : <span className="text-gray-700">{t.quantity_needed}</span>
                }
                <span className="text-gray-400 text-xs mr-1">وحدة</span>
                {t.flagged_no_sale && <span className="text-red-500 text-xs mr-1">⚠</span>}
              </td>
              <td className="px-4 py-3"><TransferBadge status={t.status} /></td>
              <td className="px-4 py-3 text-xs text-gray-500">{t.requested_by_name}</td>
              <td className="px-4 py-3 text-xs text-gray-400">{timeAgo(t.created_at)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function TransfersPage() {
  const navigate = useNavigate()
  const qc = useQueryClient()
  const { user } = useAuthStore()

  const [view, setView] = useState('list') // 'list' | 'kanban'
  const [showStockPanel, setShowStockPanel] = useState(false)
  const [createPrefill, setCreatePrefill] = useState(null)
  const [filters, setFilters] = useState({
    status: '',
    requesting_branch: '',
    source_branch: '',
    search: '',
    flagged_no_sale: '',
  })

  const isCCOrAdmin = user?.role === 'admin' || user?.role === 'call_center' || user?.role === 'purchasing'
  const userBranchId = user?.branch_id

  const { data: branches } = useQuery({
    queryKey: ['branches'],
    queryFn: () => branchesApi.list().then(r => r.data.results || r.data),
  })

  const { data: transfers = [], isLoading } = useQuery({
    queryKey: ['transfers', filters],
    queryFn: () => transfersApi.list({
      status: filters.status || undefined,
      requesting_branch: filters.requesting_branch || undefined,
      source_branch: filters.source_branch || undefined,
      search: filters.search || undefined,
      flagged_no_sale: filters.flagged_no_sale || undefined,
    }).then(r => r.data.results || r.data),
    refetchInterval: 30_000,
  })

  const handleCreateRequest = useCallback((prefill) => {
    setCreatePrefill(prefill)
  }, [])

  const handleCardClick = (transfer) => {
    navigate(`/transfers/${transfer.id}`)
  }

  const activeCount = transfers.filter(t => ['sent', 'draft'].includes(t.status)).length
  const flaggedCount = transfers.filter(t => t.flagged_no_sale).length

  return (
    <div className="flex flex-col h-full" dir="rtl">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div>
            <h1 className="text-lg font-black text-gray-900">طلبات التحويل بين الفروع</h1>
            <p className="text-xs text-gray-400">
              {transfers.length} طلب
              {activeCount > 0 && <span className="text-yellow-600 mr-2">· {activeCount} بانتظار الرد</span>}
              {flaggedCount > 0 && <span className="text-red-600 mr-2">· {flaggedCount} ⚠ غير مُصرَّف</span>}
            </p>
          </div>

          <div className="flex-1" />

          {/* View toggle */}
          <div className="flex border border-gray-200 rounded-lg overflow-hidden text-xs">
            <button
              onClick={() => setView('list')}
              className={`px-3 py-1.5 font-medium transition-colors ${view === 'list' ? 'bg-brand-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
            >☰ قائمة</button>
            <button
              onClick={() => setView('kanban')}
              className={`px-3 py-1.5 font-medium transition-colors ${view === 'kanban' ? 'bg-brand-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
            >⊞ كانبان</button>
          </div>

          {/* Stock panel toggle */}
          <button
            onClick={() => setShowStockPanel(v => !v)}
            className={`btn-secondary text-sm flex items-center gap-1.5 ${showStockPanel ? 'bg-brand-50 border-brand-300 text-brand-700' : ''}`}
          >
            🔍 {showStockPanel ? 'إخفاء البحث' : 'بحث المخزون'}
          </button>

          {/* New request */}
          <button
            onClick={() => setCreatePrefill({})}
            className="btn-primary text-sm"
          >
            + طلب تحويل جديد
          </button>
        </div>

        {/* Filters row */}
        <div className="flex gap-2 mt-3 flex-wrap">
          <input
            className="input-field w-44 text-xs"
            placeholder="بحث باسم الصنف..."
            value={filters.search}
            onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
          />
          <select className="input-field w-40 text-xs" value={filters.status}
            onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}>
            <option value="">كل الحالات</option>
            {Object.entries(TRANSFER_STATUSES).map(([k, v]) => (
              <option key={k} value={k}>{v.label}</option>
            ))}
          </select>
          {isCCOrAdmin && (
            <>
              <select className="input-field w-44 text-xs" value={filters.requesting_branch}
                onChange={e => setFilters(f => ({ ...f, requesting_branch: e.target.value }))}>
                <option value="">الفرع الطالب (الكل)</option>
                {(branches || []).map(b => <option key={b.id} value={b.id}>{b.name_ar || b.name}</option>)}
              </select>
              <select className="input-field w-44 text-xs" value={filters.source_branch}
                onChange={e => setFilters(f => ({ ...f, source_branch: e.target.value }))}>
                <option value="">الفرع المصدر (الكل)</option>
                {(branches || []).map(b => <option key={b.id} value={b.id}>{b.name_ar || b.name}</option>)}
              </select>
            </>
          )}
          <select className="input-field w-40 text-xs" value={filters.flagged_no_sale}
            onChange={e => setFilters(f => ({ ...f, flagged_no_sale: e.target.value }))}>
            <option value="">كل الطلبات</option>
            <option value="true">⚠ غير مُصرَّف فقط</option>
          </select>
          <button
            className="btn-secondary text-xs px-3"
            onClick={() => setFilters({ status: '', requesting_branch: '', source_branch: '', search: '', flagged_no_sale: '' })}
          >مسح</button>
        </div>
      </div>

      {/* Body */}
      <div className={`flex-1 overflow-auto p-5 ${showStockPanel ? 'grid grid-cols-3 gap-5' : ''}`}>
        {/* Main content area */}
        <div className={showStockPanel ? 'col-span-2' : ''}>
          {isLoading ? (
            <div className="flex flex-col gap-3 animate-pulse">
              {[1,2,3].map(i => <div key={i} className="h-16 bg-gray-100 rounded-xl" />)}
            </div>
          ) : view === 'kanban' ? (
            <KanbanBoard transfers={transfers} onCardClick={handleCardClick} />
          ) : (
            <ListView transfers={transfers} onRowClick={handleCardClick} />
          )}
        </div>

        {/* Stock lookup panel */}
        {showStockPanel && (
          <div className="col-span-1 max-h-screen sticky top-0">
            <StockLookupPanel
              onCreateRequest={handleCreateRequest}
              userBranchId={userBranchId}
              branches={branches}
            />
          </div>
        )}
      </div>

      {/* Create transfer modal */}
      {createPrefill !== null && (
        <CreateTransferModal
          prefill={createPrefill}
          branches={branches}
          userBranchId={userBranchId}
          onClose={() => setCreatePrefill(null)}
          onCreated={() => qc.invalidateQueries(['transfers'])}
        />
      )}
    </div>
  )
}
