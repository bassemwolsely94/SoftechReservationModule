"""
PATCH INSTRUCTIONS FOR apps/sync/tasks.py
==========================================

Find this block (around line 55):

        check_stock_for_pending_reservations()
        logger.info(f"Sync complete — {total} records synced")

Replace it with:

        check_stock_for_pending_reservations()

        # Fire stock-available notifications after every sync
        try:
            from django.core import management
            management.call_command('notify_stock_available', verbosity=0)
        except Exception as notif_err:
            logger.warning(f"Stock notification hook failed: {notif_err}")

        logger.info(f"Sync complete — {total} records synced")

That's the only change needed in tasks.py.
The notify_stock_available command handles its own error isolation,
so a failure never breaks the sync itself.
"""
