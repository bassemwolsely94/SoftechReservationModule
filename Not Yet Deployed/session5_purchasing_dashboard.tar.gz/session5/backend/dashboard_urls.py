from django.urls import path
from .views import dashboard_summary, purchasing_dashboard

urlpatterns = [
    path('summary/',    dashboard_summary),
    path('purchasing/', purchasing_dashboard),
]
