from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Count, Sum, Q, F
from django.utils import timezone
from datetime import date, timedelta

from apps.reservations.models import Reservation
from apps.customers.models import Customer, PurchaseHistory
from apps.catalog.models import ItemStock
from apps.sync.models import SyncRun


def _get_profile(request):
    return getattr(request.user, 'staff_profile', None)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EXISTING — GET /api/dashboard/summary/
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def dashboard_summary(request):
    today = date.today()
    week_start = today - timedelta(days=today.weekday())
    branch_id = request.query_params.get('branch')

    res_qs = Reservation.objects.all()
    profile = _get_profile(request)

    # Branch-scope non-admin staff
    if profile and profile.role not in ('admin', 'call_center', 'purchasing'):
        if profile.branch:
            res_qs = res_qs.filter(branch=profile.branch)
    elif branch_id:
        res_qs = res_qs.filter(branch_id=branch_id)

    reservation_stats = {
        'pending':            res_qs.filter(status='pending').count(),
        'available':          res_qs.filter(status='available').count(),
        'contacted':          res_qs.filter(status='contacted').count(),
        'confirmed':          res_qs.filter(status='confirmed').count(),
        'follow_ups_today':   res_qs.filter(
            follow_up_date=today,
            status__in=['pending', 'available', 'contacted']
        ).count(),
        'fulfilled_this_week': res_qs.filter(
            status='fulfilled',
            updated_at__date__gte=week_start
        ).count(),
        'urgent_active': res_qs.filter(
            priority='urgent',
            status__in=['pending', 'available', 'contacted', 'confirmed']
        ).count(),
    }

    sales_qs = PurchaseHistory.objects.filter(
        invoice_date__date__gte=today - timedelta(days=7),
        doc_code='115'
    )
    if branch_id:
        sales_qs = sales_qs.filter(branch_id=branch_id)

    sales_stats = {
        'invoices_7d': sales_qs.count(),
        'revenue_7d':  float(sales_qs.aggregate(t=Sum('total_amount'))['t'] or 0),
    }

    customer_stats = {
        'total': Customer.objects.count(),
        'new_this_month': Customer.objects.filter(
            created_at__year=today.year,
            created_at__month=today.month
        ).count(),
    }

    low_stock = ItemStock.objects.filter(
        quantity_on_hand__gt=0,
        quantity_on_hand__lt=5
    ).select_related('item', 'branch').order_by('quantity_on_hand')[:10]

    stock_alerts = [
        {
            'item_name':   s.item.name,
            'branch_name': s.branch.name_ar or s.branch.name,
            'quantity':    float(s.quantity_on_hand),
        }
        for s in low_stock
    ]

    last_sync = SyncRun.objects.first()
    sync_info = {
        'status':  last_sync.status if last_sync else 'never',
        'last_at': last_sync.completed_at.isoformat()
                   if last_sync and last_sync.completed_at else None,
        'records': last_sync.records_synced if last_sync else 0,
    }

    # Bonus: surface transfer counts for the main dashboard too
    transfer_pending = 0
    transfer_flagged = 0
    try:
        from django.apps import apps as _apps
        TR = _apps.get_model('transfers', 'TransferRequest')
        transfer_pending = TR.objects.filter(status='sent').count()
        transfer_flagged = TR.objects.filter(flagged_no_sale=True).count()
    except Exception:
        pass

    return Response({
        'reservations':     reservation_stats,
        'sales':            sales_stats,
        'customers':        customer_stats,
        'stock_alerts':     stock_alerts,
        'sync':             sync_info,
        'transfer_pending': transfer_pending,
        'transfer_flagged': transfer_flagged,
        'generated_at':     timezone.now().isoformat(),
    })


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# NEW — GET /api/dashboard/purchasing/
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def purchasing_dashboard(request):
    """
    Full purchasing analytics.
    Roles: admin, purchasing only.

    Query params:
      ?days=30   — look-back window (default 30, max 180)
    """
    profile = _get_profile(request)
    if not profile or profile.role not in ('admin', 'purchasing'):
        return Response(
            {'detail': 'هذه الصفحة مخصصة لقسم المشتريات والمديرين فقط'},
            status=403,
        )

    try:
        from django.apps import apps as _apps
        TR = _apps.get_model('transfers', 'TransferRequest')
    except Exception:
        return Response(
            {'detail': 'تطبيق التحويلات غير مُثبَّت بعد. تأكد من تشغيل migrate.'},
            status=503,
        )

    now         = timezone.now()
    days        = min(int(request.query_params.get('days', 30)), 180)
    win_start   = now - timedelta(days=days)
    week_start  = now - timedelta(days=7)

    tr_win  = TR.objects.filter(created_at__gte=win_start)
    tr_week = TR.objects.filter(created_at__gte=week_start)

    # ── KPI counters ─────────────────────────────────────────────────────────
    total        = tr_win.count()
    n_accepted   = tr_win.filter(status__in=['accepted', 'fulfilled']).count()
    n_partial    = tr_win.filter(status='partial').count()
    n_rejected   = tr_win.filter(status='rejected').count()
    n_fulfilled  = tr_win.filter(status='fulfilled').count()
    n_pending    = TR.objects.filter(status='sent').count()          # live count
    n_flagged    = TR.objects.filter(flagged_no_sale=True).count()   # live count

    accept_rate  = round((n_accepted + n_partial) / total * 100, 1) if total else 0

    # Average response time in hours
    responded = TR.objects.filter(
        created_at__gte=win_start,
        responded_at__isnull=False,
    ).only('created_at', 'responded_at')
    avg_hrs = None
    if responded.exists():
        secs = sum(
            (t.responded_at - t.created_at).total_seconds()
            for t in responded
        )
        avg_hrs = round(secs / responded.count() / 3600, 1)

    # ── Weekly status breakdown ───────────────────────────────────────────────
    weekly_breakdown = list(
        tr_week
        .values('status')
        .annotate(count=Count('id'))
        .order_by('status')
    )

    # ── Daily trend — last N days ─────────────────────────────────────────────
    daily_trend = []
    for i in range(days - 1, -1, -1):
        d = (now - timedelta(days=i)).date()
        daily_trend.append({
            'date':  str(d),
            'count': TR.objects.filter(
                created_at__date=d
            ).count(),
        })

    # ── Top 10 items ──────────────────────────────────────────────────────────
    top_items = list(
        tr_win.exclude(status='cancelled')
        .values('item__id', 'item__name', 'item__softech_id')
        .annotate(
            request_count  = Count('id'),
            total_qty      = Sum('quantity_needed'),
            accepted_count = Count('id', filter=Q(status__in=['accepted', 'partial', 'fulfilled'])),
            rejected_count = Count('id', filter=Q(status='rejected')),
        )
        .order_by('-request_count')[:10]
    )
    for row in top_items:
        rc = row['request_count']
        row['acceptance_rate'] = round(row['accepted_count'] / rc * 100) if rc else 0
        row['total_qty'] = float(row['total_qty'] or 0)

    # ── Recommended for regular HQ order (≥3 requests in window) ─────────────
    recommended = [
        {
            'item_id':       row['item__id'],
            'item_name':     row['item__name'],
            'softech_id':    row['item__softech_id'],
            'request_count': row['request_count'],
            'total_qty':     row['total_qty'],
            'accept_rate':   row['acceptance_rate'],
            'reason':        f'طُلب تحويله {row["request_count"]} مرة خلال {days} يوماً',
        }
        for row in top_items
        if row['request_count'] >= 3
    ]

    # ── Top requesting branches ───────────────────────────────────────────────
    top_requestors = []
    for row in (
        tr_win.exclude(status='cancelled')
        .values('requesting_branch__id', 'requesting_branch__name_ar', 'requesting_branch__name')
        .annotate(
            count        = Count('id'),
            qty_total    = Sum('quantity_needed'),
            n_rejected   = Count('id', filter=Q(status='rejected')),
        )
        .order_by('-count')[:8]
    ):
        top_requestors.append({
            'branch_id':      row['requesting_branch__id'],
            'branch_name':    row['requesting_branch__name_ar'] or row['requesting_branch__name'],
            'count':          row['count'],
            'qty_total':      float(row['qty_total'] or 0),
            'rejection_rate': round(row['n_rejected'] / row['count'] * 100) if row['count'] else 0,
        })

    # ── Top source branches ───────────────────────────────────────────────────
    top_sources = []
    for row in (
        tr_win.exclude(status='cancelled')
        .values('source_branch__id', 'source_branch__name_ar', 'source_branch__name')
        .annotate(
            count      = Count('id'),
            n_accepted = Count('id', filter=Q(status__in=['accepted', 'partial', 'fulfilled'])),
            n_rejected = Count('id', filter=Q(status='rejected')),
        )
        .order_by('-count')[:8]
    ):
        top_sources.append({
            'branch_id':      row['source_branch__id'],
            'branch_name':    row['source_branch__name_ar'] or row['source_branch__name'],
            'count':          row['count'],
            'acceptance_rate': round(row['n_accepted'] / row['count'] * 100) if row['count'] else 0,
        })

    # ── Rejection reasons breakdown ───────────────────────────────────────────
    REASON_LABELS = {
        'insufficient_stock':  'مخزون غير كافٍ',
        'reserved_customers':  'محجوز لعملاء الفرع',
        'item_on_order':       'الصنف قيد الأوردر',
        'other':               'أخرى',
        '':                    'غير محدد',
    }
    rejection_reasons = [
        {
            'reason':  row['rejection_reason'],
            'label':   REASON_LABELS.get(row['rejection_reason'], row['rejection_reason']),
            'count':   row['count'],
        }
        for row in (
            TR.objects.filter(created_at__gte=win_start, status='rejected')
            .values('rejection_reason')
            .annotate(count=Count('id'))
            .order_by('-count')
        )
    ]

    # ── Flagged list — accepted transfers with no sale in 14 days ────────────
    flagged_list = []
    for t in (
        TR.objects.filter(flagged_no_sale=True)
        .select_related('item', 'requesting_branch', 'source_branch')
        .order_by('-responded_at')[:20]
    ):
        days_since = (
            (now - t.responded_at).days if t.responded_at else None
        )
        flagged_list.append({
            'id':           t.id,
            'item_name':    t.item.name,
            'softech_id':   t.item.softech_id,
            'branch_name':  t.requesting_branch.name_ar or t.requesting_branch.name,
            'source_name':  t.source_branch.name_ar or t.source_branch.name,
            'qty':          float(t.quantity_approved or t.quantity_needed or 0),
            'days_since':   days_since,
            'responded_at': t.responded_at.isoformat() if t.responded_at else None,
        })

    # ── Inter-branch flow matrix (top 15 pairs) ───────────────────────────────
    flow_matrix = [
        {
            'from':  r['requesting_branch__name_ar'] or r['requesting_branch__name'],
            'to':    r['source_branch__name_ar']     or r['source_branch__name'],
            'count': r['count'],
        }
        for r in (
            tr_win.exclude(status='cancelled')
            .values(
                'requesting_branch__name_ar', 'requesting_branch__name',
                'source_branch__name_ar',     'source_branch__name',
            )
            .annotate(count=Count('id'))
            .order_by('-count')[:15]
        )
    ]

    return Response({
        'window_days':      days,
        'generated_at':     now.isoformat(),

        'kpis': {
            'total':           total,
            'accepted':        n_accepted,
            'partial':         n_partial,
            'rejected':        n_rejected,
            'fulfilled':       n_fulfilled,
            'pending':         n_pending,
            'flagged':         n_flagged,
            'accept_rate':     accept_rate,
            'avg_response_hrs': avg_hrs,
        },

        'weekly_breakdown':  weekly_breakdown,
        'daily_trend':       daily_trend,
        'top_items':         top_items,
        'recommended':       recommended,
        'top_requestors':    top_requestors,
        'top_sources':       top_sources,
        'rejection_reasons': rejection_reasons,
        'flagged_list':      flagged_list,
        'flow_matrix':       flow_matrix,
    })
