// ── add this block to the bottom of frontend/src/api/client.js ──

export const purchasingApi = {
  dashboard: (days = 30) =>
    api.get('/dashboard/purchasing/', { params: { days } }),
}
