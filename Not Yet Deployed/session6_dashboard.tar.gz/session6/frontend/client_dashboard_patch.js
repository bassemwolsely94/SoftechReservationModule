// ── Replace the existing dashboardApi block in frontend/src/api/client.js ──
// Find:
//   export const dashboardApi = {
//     summary: (params) => api.get('/dashboard/summary/', { params }),
//   }
//
// Replace with:

export const dashboardApi = {
  summary:   (params) => api.get('/dashboard/summary/', { params }),
  followups: ()       => api.get('/dashboard/followups/'),
  purchasing:(days)   => api.get('/dashboard/purchasing/', { params: { days } }),
}
