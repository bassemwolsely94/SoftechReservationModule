// ── Replace the existing customersApi block in frontend/src/api/client.js ──
// Find the block that starts with:
//   export const customersApi = {
// and replace the entire block with:

export const customersApi = {
  list:       (params) => api.get('/customers/', { params }),
  get:        (id) => api.get(`/customers/${id}/`),
  create:     (data) => api.post('/customers/', data),
  update:     (id, data) => api.patch(`/customers/${id}/`, data),

  // purchases — pass doc_code param if filtering
  purchases:  (id, docCode) =>
    api.get(`/customers/${id}/purchases/`,
      docCode ? { params: { doc_code: docCode } } : {}),

  reservations: (id) => api.get(`/customers/${id}/reservations/`),
  topItems:     (id) => api.get(`/customers/${id}/top_items/`),
  addNote:      (id, note) => api.post(`/customers/${id}/notes/`, { note }),
  deleteNote:   (customerId, noteId) =>
    api.delete(`/customers/${customerId}/notes/${noteId}/`),
  updateConditions: (id, chronic_conditions) =>
    api.patch(`/customers/${id}/update_conditions/`, { chronic_conditions }),
}
