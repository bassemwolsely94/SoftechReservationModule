from django.contrib import admin
from .models import TransferRequest


@admin.register(TransferRequest)
class TransferRequestAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'item', 'requesting_branch', 'source_branch',
        'quantity_needed', 'quantity_approved', 'status',
        'requested_by', 'responded_by', 'flagged_no_sale', 'created_at',
    ]
    list_filter = ['status', 'requesting_branch', 'source_branch', 'flagged_no_sale']
    search_fields = ['item__name', 'item__softech_id', 'request_note', 'response_note']
    readonly_fields = ['created_at', 'responded_at', 'fulfilled_at']
    raw_id_fields = ['item', 'linked_reservation', 'fulfillment_reservation']
    ordering = ['-created_at']

    fieldsets = (
        ('الطلب', {
            'fields': (
                'requesting_branch', 'source_branch', 'item',
                'quantity_needed', 'linked_reservation',
                'requested_by', 'request_note', 'status',
            )
        }),
        ('الرد', {
            'fields': (
                'quantity_approved', 'responded_by',
                'rejection_reason', 'rejection_reason_text', 'response_note',
            )
        }),
        ('التنفيذ', {
            'fields': ('fulfillment_reservation', 'flagged_no_sale'),
        }),
        ('التواريخ', {
            'fields': ('created_at', 'responded_at', 'fulfilled_at'),
        }),
    )
