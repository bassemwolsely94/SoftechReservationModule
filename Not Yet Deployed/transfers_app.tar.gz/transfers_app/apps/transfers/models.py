from django.db import models


class TransferRequest(models.Model):

    STATUS_CHOICES = [
        ('draft',     'مسودة'),
        ('sent',      'مُرسَل — بانتظار الرد'),
        ('accepted',  'مقبول بالكامل'),
        ('partial',   'مقبول جزئياً'),
        ('rejected',  'مرفوض'),
        ('fulfilled', 'تم التنفيذ'),
        ('cancelled', 'ملغي'),
    ]

    REJECTION_REASON_CHOICES = [
        ('insufficient_stock',  'مخزون غير كافٍ'),
        ('reserved_customers',  'مخزون محجوز لعملاء الفرع'),
        ('item_on_order',       'الصنف قيد الأوردر'),
        ('other',               'أخرى'),
    ]

    # ── Core relationship fields ───────────────────────────────────────────────
    requesting_branch = models.ForeignKey(
        'branches.Branch',
        on_delete=models.PROTECT,
        related_name='outgoing_transfers',
        verbose_name='الفرع الطالب',
    )
    source_branch = models.ForeignKey(
        'branches.Branch',
        on_delete=models.PROTECT,
        related_name='incoming_transfers',
        verbose_name='الفرع المصدر',
    )
    item = models.ForeignKey(
        'catalog.Item',
        on_delete=models.PROTECT,
        related_name='transfer_requests',
        verbose_name='الصنف',
    )

    # ── Quantities ─────────────────────────────────────────────────────────────
    quantity_needed = models.DecimalField(
        max_digits=10, decimal_places=3,
        verbose_name='الكمية المطلوبة',
    )
    quantity_approved = models.DecimalField(
        max_digits=10, decimal_places=3,
        null=True, blank=True,
        verbose_name='الكمية المعتمدة',
    )

    # ── Linked reservation (optional) ─────────────────────────────────────────
    linked_reservation = models.ForeignKey(
        'reservations.Reservation',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='transfer_requests',
        verbose_name='الحجز المرتبط',
    )
    fulfillment_reservation = models.ForeignKey(
        'reservations.Reservation',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='fulfilled_by_transfers',
        verbose_name='الحجز الذي تم تنفيذه',
    )

    # ── People ─────────────────────────────────────────────────────────────────
    requested_by = models.ForeignKey(
        'users.StaffProfile',
        on_delete=models.PROTECT,
        related_name='transfer_requests_made',
        verbose_name='طُلب بواسطة',
    )
    responded_by = models.ForeignKey(
        'users.StaffProfile',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='transfer_requests_responded',
        verbose_name='تم الرد بواسطة',
    )

    # ── Status & notes ─────────────────────────────────────────────────────────
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='draft',
        db_index=True,
        verbose_name='الحالة',
    )
    request_note = models.TextField(
        blank=True,
        verbose_name='ملاحظة الطلب',
    )
    rejection_reason = models.CharField(
        max_length=30,
        choices=REJECTION_REASON_CHOICES,
        blank=True,
        verbose_name='سبب الرفض',
    )
    rejection_reason_text = models.TextField(
        blank=True,
        verbose_name='تفاصيل سبب الرفض',
    )
    response_note = models.TextField(
        blank=True,
        verbose_name='ملاحظة الرد',
    )

    # ── Policy enforcement flag ────────────────────────────────────────────────
    flagged_no_sale = models.BooleanField(
        default=False,
        db_index=True,
        verbose_name='مُعلَّم: لا مبيعات بعد التحويل',
    )

    # ── Timestamps ─────────────────────────────────────────────────────────────
    created_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'طلب تحويل'
        verbose_name_plural = 'طلبات التحويل'
        indexes = [
            models.Index(fields=['status', 'requesting_branch']),
            models.Index(fields=['status', 'source_branch']),
            models.Index(fields=['flagged_no_sale']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return (
            f"طلب #{self.id} | {self.item.name} | "
            f"{self.requesting_branch} ← {self.source_branch} | "
            f"{self.get_status_display()}"
        )

    @property
    def status_color(self):
        return {
            'draft':     'gray',
            'sent':      'yellow',
            'accepted':  'green',
            'partial':   'blue',
            'rejected':  'red',
            'fulfilled': 'green',
            'cancelled': 'red',
        }.get(self.status, 'gray')

    @property
    def status_label_ar(self):
        return dict(self.STATUS_CHOICES).get(self.status, self.status)

    @property
    def is_active(self):
        return self.status in ('draft', 'sent')

    @property
    def is_responded(self):
        return self.status in ('accepted', 'partial', 'rejected')
