"""
apps/transfers/notifications.py

Notification helpers for transfer request events.
Works with the existing apps.notifications.models.Notification model
(or creates a fallback inline if notifications app is not installed).
"""
import logging
from django.apps import apps

logger = logging.getLogger('elrezeiky.transfers')


def _get_notification_model():
    try:
        return apps.get_model('notifications', 'Notification')
    except LookupError:
        return None


def _branch_staff(branch):
    """Return all active StaffProfiles for a given branch."""
    StaffProfile = apps.get_model('users', 'StaffProfile')
    return StaffProfile.objects.filter(
        branch=branch,
        is_active=True,
        role__in=('admin', 'pharmacist', 'salesperson', 'call_center'),
    )


def _purchasing_staff():
    """Return all purchasing dept + admin staff."""
    StaffProfile = apps.get_model('users', 'StaffProfile')
    return StaffProfile.objects.filter(
        is_active=True,
        role__in=('admin', 'purchasing'),
    )


def notify_source_branch_new_request(transfer):
    """
    Step 3: Fire notifications to ALL users at the source branch
    when a transfer request is created.
    """
    Notification = _get_notification_model()
    if not Notification:
        logger.warning('notifications app not installed — skipping notify_source_branch_new_request')
        return

    title = f'طلب تحويل جديد — {transfer.item.name}'
    body = (
        f'فرع {transfer.requesting_branch.name_ar or transfer.requesting_branch.name} '
        f'يطلب {transfer.quantity_needed} وحدة من الصنف: {transfer.item.name}. '
        f'يرجى مراجعة الطلب والرد.'
    )

    recipients = _branch_staff(transfer.source_branch)
    bulk = []
    for staff in recipients:
        notif_kwargs = dict(
            recipient=staff,
            title=title,
            body=body,
            is_read=False,
        )
        # Attach transfer FK if the Notification model supports it
        if hasattr(Notification, 'transfer_request'):
            notif_kwargs['transfer_request'] = transfer
        if hasattr(Notification, 'notification_type'):
            notif_kwargs['notification_type'] = 'transfer_request'
        bulk.append(Notification(**notif_kwargs))

    if bulk:
        Notification.objects.bulk_create(bulk)
        logger.info(
            f'Transfer #{transfer.id}: notified {len(bulk)} users at '
            f'{transfer.source_branch}'
        )


def notify_requesting_branch_response(transfer):
    """
    Step 5: Notify the REQUESTING branch users of the response
    (accept / partial / reject).
    """
    Notification = _get_notification_model()
    if not Notification:
        return

    status_labels = {
        'accepted': 'تم القبول الكامل ✅',
        'partial':  'تم القبول الجزئي ⚠️',
        'rejected': 'تم الرفض ❌',
    }
    status_text = status_labels.get(transfer.status, transfer.get_status_display())

    title = f'رد على طلب التحويل — {transfer.item.name}'
    body = (
        f'فرع {transfer.source_branch.name_ar or transfer.source_branch.name} '
        f'رد على طلبك للصنف {transfer.item.name}: {status_text}.'
    )
    if transfer.status == 'partial' and transfer.quantity_approved:
        body += f' الكمية المعتمدة: {transfer.quantity_approved} وحدة.'
    if transfer.rejection_reason_text:
        body += f' السبب: {transfer.rejection_reason_text}'

    recipients = _branch_staff(transfer.requesting_branch)
    bulk = []
    for staff in recipients:
        notif_kwargs = dict(
            recipient=staff,
            title=title,
            body=body,
            is_read=False,
        )
        if hasattr(Notification, 'transfer_request'):
            notif_kwargs['transfer_request'] = transfer
        if hasattr(Notification, 'notification_type'):
            notif_kwargs['notification_type'] = 'transfer_response'
        bulk.append(Notification(**notif_kwargs))

    if bulk:
        Notification.objects.bulk_create(bulk)


def notify_purchasing_rejection(transfer):
    """
    Step 5b: When a transfer is REJECTED, notify purchasing dept.
    They need to decide if this should come from HQ instead.
    """
    Notification = _get_notification_model()
    if not Notification:
        return

    title = f'طلب تحويل مرفوض — يحتاج مراجعة المشتريات'
    body = (
        f'فرع {transfer.requesting_branch.name_ar} طلب {transfer.quantity_needed} '
        f'وحدة من {transfer.item.name} من فرع '
        f'{transfer.source_branch.name_ar} وتم رفضه. '
        f'السبب: {transfer.get_rejection_reason_display() or "غير محدد"}. '
        f'يرجى مراجعة إمكانية الطلب من المستودع الرئيسي.'
    )

    recipients = _purchasing_staff()
    bulk = []
    for staff in recipients:
        notif_kwargs = dict(
            recipient=staff,
            title=title,
            body=body,
            is_read=False,
        )
        if hasattr(Notification, 'transfer_request'):
            notif_kwargs['transfer_request'] = transfer
        if hasattr(Notification, 'notification_type'):
            notif_kwargs['notification_type'] = 'transfer_request'
        bulk.append(Notification(**notif_kwargs))

    if bulk:
        Notification.objects.bulk_create(bulk)


def notify_unfulfilled_flag(transfer):
    """
    Policy enforcement: notify purchasing when a transfer has been
    accepted but no sale recorded after 14 days.
    """
    Notification = _get_notification_model()
    if not Notification:
        return

    from django.utils import timezone
    days = (timezone.now() - transfer.responded_at).days if transfer.responded_at else '?'

    title = f'تحذير: مخزون محوَّل غير مُصرَّف — {transfer.item.name}'
    body = (
        f'فرع {transfer.requesting_branch.name_ar} طلب {transfer.quantity_approved or transfer.quantity_needed} '
        f'وحدة من الصنف {transfer.item.name} منذ {days} يوماً '
        f'ولم يُسجَّل أي مبيعات. يرجى المتابعة.'
    )

    recipients = _purchasing_staff()
    bulk = []
    for staff in recipients:
        notif_kwargs = dict(
            recipient=staff,
            title=title,
            body=body,
            is_read=False,
        )
        if hasattr(Notification, 'transfer_request'):
            notif_kwargs['transfer_request'] = transfer
        if hasattr(Notification, 'notification_type'):
            notif_kwargs['notification_type'] = 'unfulfilled_transfer_flag'
        bulk.append(Notification(**notif_kwargs))

    if bulk:
        Notification.objects.bulk_create(bulk)
        transfer.flagged_no_sale = True
        transfer.save(update_fields=['flagged_no_sale'])
