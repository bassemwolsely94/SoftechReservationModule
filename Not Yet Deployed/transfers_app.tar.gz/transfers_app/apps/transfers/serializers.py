from rest_framework import serializers
from .models import TransferRequest
from apps.catalog.models import ItemStock


class TransferRequestListSerializer(serializers.ModelSerializer):
    requesting_branch_name = serializers.CharField(
        source='requesting_branch.name_ar', read_only=True
    )
    source_branch_name = serializers.CharField(
        source='source_branch.name_ar', read_only=True
    )
    item_name = serializers.CharField(source='item.name', read_only=True)
    item_softech_id = serializers.CharField(source='item.softech_id', read_only=True)
    requested_by_name = serializers.CharField(source='requested_by.full_name', read_only=True)
    responded_by_name = serializers.CharField(source='responded_by.full_name', read_only=True)
    status_label = serializers.CharField(source='status_label_ar', read_only=True)
    status_color = serializers.CharField(read_only=True)
    linked_reservation_id = serializers.IntegerField(
        source='linked_reservation.id', read_only=True
    )

    class Meta:
        model = TransferRequest
        fields = [
            'id',
            'requesting_branch', 'requesting_branch_name',
            'source_branch', 'source_branch_name',
            'item', 'item_name', 'item_softech_id',
            'quantity_needed', 'quantity_approved',
            'status', 'status_label', 'status_color',
            'requested_by_name', 'responded_by_name',
            'linked_reservation_id',
            'flagged_no_sale',
            'created_at', 'responded_at', 'fulfilled_at',
        ]


class TransferRequestDetailSerializer(serializers.ModelSerializer):
    requesting_branch_name = serializers.CharField(
        source='requesting_branch.name_ar', read_only=True
    )
    source_branch_name = serializers.CharField(
        source='source_branch.name_ar', read_only=True
    )
    item_name = serializers.CharField(source='item.name', read_only=True)
    item_softech_id = serializers.CharField(source='item.softech_id', read_only=True)
    item_scientific = serializers.CharField(source='item.name_scientific', read_only=True)
    requested_by_name = serializers.CharField(source='requested_by.full_name', read_only=True)
    requested_by_branch = serializers.CharField(
        source='requested_by.branch_name', read_only=True
    )
    responded_by_name = serializers.CharField(source='responded_by.full_name', read_only=True)
    status_label = serializers.CharField(source='status_label_ar', read_only=True)
    status_color = serializers.CharField(read_only=True)
    rejection_reason_label = serializers.SerializerMethodField()

    # Live stock at ALL branches for this item
    stock_by_branch = serializers.SerializerMethodField()

    # Pending reservations at source branch for this item (conflict check)
    source_branch_reservations = serializers.SerializerMethodField()

    def get_rejection_reason_label(self, obj):
        return dict(TransferRequest.REJECTION_REASON_CHOICES).get(
            obj.rejection_reason, obj.rejection_reason
        )

    def get_stock_by_branch(self, obj):
        stocks = ItemStock.objects.filter(item=obj.item).select_related('branch')
        return [
            {
                'branch_id': s.branch.id,
                'branch_name': s.branch.name_ar or s.branch.name,
                'quantity': float(s.quantity_on_hand),
                'is_source': s.branch_id == obj.source_branch_id,
                'is_requesting': s.branch_id == obj.requesting_branch_id,
            }
            for s in stocks
        ]

    def get_source_branch_reservations(self, obj):
        from apps.reservations.models import Reservation
        pending = Reservation.objects.filter(
            item=obj.item,
            branch=obj.source_branch,
            status__in=['pending', 'available', 'contacted', 'confirmed'],
        ).select_related('customer')
        return [
            {
                'id': r.id,
                'customer_name': r.customer.name,
                'quantity': float(r.quantity_requested),
                'status': r.status,
                'status_label': r.status_label_ar,
            }
            for r in pending
        ]

    class Meta:
        model = TransferRequest
        fields = [
            'id',
            'requesting_branch', 'requesting_branch_name',
            'source_branch', 'source_branch_name',
            'item', 'item_name', 'item_softech_id', 'item_scientific',
            'quantity_needed', 'quantity_approved',
            'linked_reservation', 'fulfillment_reservation',
            'requested_by', 'requested_by_name', 'requested_by_branch',
            'responded_by', 'responded_by_name',
            'status', 'status_label', 'status_color',
            'request_note',
            'rejection_reason', 'rejection_reason_label', 'rejection_reason_text',
            'response_note',
            'flagged_no_sale',
            'stock_by_branch',
            'source_branch_reservations',
            'created_at', 'responded_at', 'fulfilled_at',
        ]
        read_only_fields = [
            'status', 'requested_by', 'responded_by',
            'responded_at', 'fulfilled_at', 'flagged_no_sale',
        ]


class TransferRequestCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = TransferRequest
        fields = [
            'requesting_branch', 'source_branch', 'item',
            'quantity_needed', 'linked_reservation', 'request_note',
        ]

    def validate(self, data):
        if data['requesting_branch'] == data['source_branch']:
            raise serializers.ValidationError(
                'لا يمكن طلب التحويل من نفس الفرع'
            )
        if data['quantity_needed'] <= 0:
            raise serializers.ValidationError(
                'الكمية المطلوبة يجب أن تكون أكبر من صفر'
            )
        return data


class TransferRespondSerializer(serializers.Serializer):
    """Used by source branch to accept/partial/reject a transfer request."""
    action = serializers.ChoiceField(choices=['accept', 'partial', 'reject'])
    quantity_approved = serializers.DecimalField(
        max_digits=10, decimal_places=3,
        required=False, allow_null=True,
    )
    rejection_reason = serializers.ChoiceField(
        choices=[r[0] for r in TransferRequest.REJECTION_REASON_CHOICES],
        required=False, allow_blank=True,
    )
    rejection_reason_text = serializers.CharField(
        required=False, allow_blank=True,
    )
    response_note = serializers.CharField(
        required=False, allow_blank=True,
    )

    def validate(self, data):
        action = data.get('action')
        if action == 'partial':
            if not data.get('quantity_approved'):
                raise serializers.ValidationError(
                    'يجب تحديد الكمية المعتمدة عند القبول الجزئي'
                )
        if action == 'reject':
            if not data.get('rejection_reason'):
                raise serializers.ValidationError(
                    'يجب تحديد سبب الرفض'
                )
        return data


class TransferFulfillSerializer(serializers.Serializer):
    """Marks a transfer as fulfilled, optionally linking a reservation."""
    fulfillment_reservation = serializers.IntegerField(required=False, allow_null=True)
