from django.utils import timezone
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from .models import TransferRequest
from .serializers import (
    TransferRequestListSerializer,
    TransferRequestDetailSerializer,
    TransferRequestCreateSerializer,
    TransferRespondSerializer,
    TransferFulfillSerializer,
)
from .permissions import CanCreateTransfer, CanRespondToTransfer, CanViewTransfer
from .notifications import (
    notify_source_branch_new_request,
    notify_requesting_branch_response,
    notify_purchasing_rejection,
)


def get_profile(request):
    try:
        return request.user.staff_profile
    except Exception:
        return None


class TransferRequestViewSet(viewsets.ModelViewSet):
    """
    Full CRUD + custom actions for inter-branch transfer requests.

    Actions:
        list        GET  /api/transfers/
        create      POST /api/transfers/
        retrieve    GET  /api/transfers/{id}/
        respond     POST /api/transfers/{id}/respond/
        fulfill     POST /api/transfers/{id}/fulfill/
        cancel      POST /api/transfers/{id}/cancel/
        item_stock  GET  /api/transfers/item_stock/?item_id=X
    """

    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'requesting_branch', 'source_branch', 'item', 'flagged_no_sale']
    search_fields = ['item__name', 'item__softech_id', 'request_note', 'response_note']
    ordering_fields = ['created_at', 'responded_at', 'status']
    ordering = ['-created_at']

    def get_queryset(self):
        profile = get_profile(self.request)
        qs = TransferRequest.objects.select_related(
            'requesting_branch', 'source_branch', 'item',
            'requested_by__user', 'responded_by__user',
            'linked_reservation', 'fulfillment_reservation',
        )

        if not profile:
            return qs.none()

        # Admin / call_center / purchasing → see all
        if profile.role in ('admin', 'call_center', 'purchasing'):
            return qs

        # Branch staff → only transfers involving their branch
        if profile.branch:
            return qs.filter(
                requesting_branch=profile.branch
            ) | qs.filter(
                source_branch=profile.branch
            )

        return qs.none()

    def get_serializer_class(self):
        if self.action == 'list':
            return TransferRequestListSerializer
        if self.action == 'create':
            return TransferRequestCreateSerializer
        return TransferRequestDetailSerializer

    def perform_create(self, serializer):
        profile = get_profile(self.request)
        transfer = serializer.save(
            requested_by=profile,
            status='sent',  # auto-send on creation
        )
        # Fire notifications to source branch users
        notify_source_branch_new_request(transfer)

    # ── Respond: source branch accepts / partial / rejects ────────────────────
    @action(detail=True, methods=['post'], url_path='respond')
    def respond(self, request, pk=None):
        transfer = self.get_object()
        profile = get_profile(request)

        # Permission check: must be source branch staff or admin
        perm = CanRespondToTransfer()
        if not perm.has_object_permission(request, self, transfer):
            return Response(
                {'detail': perm.message},
                status=status.HTTP_403_FORBIDDEN,
            )

        if transfer.status not in ('sent', 'draft'):
            return Response(
                {'detail': 'لا يمكن الرد على طلب تم الرد عليه مسبقاً'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = TransferRespondSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        action_type = d['action']

        # Map action → status
        status_map = {
            'accept':  'accepted',
            'partial': 'partial',
            'reject':  'rejected',
        }
        new_status = status_map[action_type]

        transfer.status = new_status
        transfer.responded_by = profile
        transfer.responded_at = timezone.now()
        transfer.response_note = d.get('response_note', '')

        if action_type == 'partial':
            transfer.quantity_approved = d['quantity_approved']
        elif action_type == 'accept':
            transfer.quantity_approved = transfer.quantity_needed
        elif action_type == 'reject':
            transfer.rejection_reason = d.get('rejection_reason', '')
            transfer.rejection_reason_text = d.get('rejection_reason_text', '')

        transfer.save()

        # Notify requesting branch
        notify_requesting_branch_response(transfer)

        # If rejected → notify purchasing dept
        if action_type == 'reject':
            notify_purchasing_rejection(transfer)

        return Response(
            TransferRequestDetailSerializer(transfer, context={'request': request}).data
        )

    # ── Fulfill: requesting branch confirms stock was received & dispensed ─────
    @action(detail=True, methods=['post'], url_path='fulfill')
    def fulfill(self, request, pk=None):
        transfer = self.get_object()
        profile = get_profile(request)

        # Only requesting branch staff or admin
        if profile.role != 'admin':
            if not profile.branch or profile.branch_id != transfer.requesting_branch_id:
                return Response(
                    {'detail': 'فقط مستخدمو الفرع الطالب يمكنهم تأكيد التنفيذ'},
                    status=status.HTTP_403_FORBIDDEN,
                )

        if transfer.status not in ('accepted', 'partial'):
            return Response(
                {'detail': 'لا يمكن تأكيد تنفيذ طلب لم يُقبل بعد'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = TransferFulfillSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        transfer.status = 'fulfilled'
        transfer.fulfilled_at = timezone.now()

        res_id = serializer.validated_data.get('fulfillment_reservation')
        if res_id:
            from apps.reservations.models import Reservation
            try:
                res = Reservation.objects.get(pk=res_id)
                transfer.fulfillment_reservation = res
            except Reservation.DoesNotExist:
                pass

        transfer.save()

        return Response(
            TransferRequestDetailSerializer(transfer, context={'request': request}).data
        )

    # ── Cancel ────────────────────────────────────────────────────────────────
    @action(detail=True, methods=['post'], url_path='cancel')
    def cancel(self, request, pk=None):
        transfer = self.get_object()
        profile = get_profile(request)

        # Only the requestor's branch or admin can cancel
        if profile.role != 'admin':
            if not profile.branch or profile.branch_id != transfer.requesting_branch_id:
                return Response(
                    {'detail': 'فقط مستخدمو الفرع الطالب يمكنهم الإلغاء'},
                    status=status.HTTP_403_FORBIDDEN,
                )

        if transfer.status in ('fulfilled', 'cancelled'):
            return Response(
                {'detail': 'لا يمكن إلغاء طلب منتهٍ أو مُلغى'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        transfer.status = 'cancelled'
        transfer.save(update_fields=['status'])

        return Response({'detail': 'تم إلغاء الطلب'}, status=status.HTTP_200_OK)

    # ── Item stock lookup across all branches ─────────────────────────────────
    @action(detail=False, methods=['get'], url_path='item_stock')
    def item_stock(self, request):
        """
        GET /api/transfers/item_stock/?item_id=123
        Returns stock for this item at ALL branches + active reservation counts.
        Used by the requesting branch before creating a transfer.
        """
        item_id = request.query_params.get('item_id')
        if not item_id:
            return Response(
                {'detail': 'item_id مطلوب'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        from apps.catalog.models import Item, ItemStock
        from apps.reservations.models import Reservation
        from django.db.models import Count, Q

        try:
            item = Item.objects.get(pk=item_id)
        except Item.DoesNotExist:
            return Response({'detail': 'الصنف غير موجود'}, status=status.HTTP_404_NOT_FOUND)

        stocks = ItemStock.objects.filter(item=item).select_related('branch')

        # Active reservation counts per branch for this item
        res_counts = (
            Reservation.objects
            .filter(item=item, status__in=['pending', 'available', 'contacted', 'confirmed'])
            .values('branch_id')
            .annotate(count=Count('id'))
        )
        res_map = {r['branch_id']: r['count'] for r in res_counts}

        stock_data = [
            {
                'branch_id': s.branch.id,
                'branch_name': s.branch.name_ar or s.branch.name,
                'quantity_on_hand': float(s.quantity_on_hand),
                'monthly_qty': float(s.monthly_qty),
                'stock_status': s.stock_status,
                'stock_status_label': s.stock_status_label,
                'active_reservations': res_map.get(s.branch_id, 0),
            }
            for s in stocks
        ]

        # Active transfer requests for this item (to show existing requests)
        active_transfers = TransferRequest.objects.filter(
            item=item,
            status__in=['sent', 'draft', 'accepted', 'partial'],
        ).values(
            'id', 'status', 'quantity_needed',
            'requesting_branch__name_ar', 'source_branch__name_ar',
        )

        return Response({
            'item': {
                'id': item.id,
                'name': item.name,
                'softech_id': item.softech_id,
                'name_scientific': item.name_scientific,
            },
            'stock_by_branch': stock_data,
            'active_transfer_requests': list(active_transfers),
        })

    # ── Purchasing: flagged transfers dashboard ────────────────────────────────
    @action(detail=False, methods=['get'], url_path='flagged')
    def flagged(self, request):
        """GET /api/transfers/flagged/ — purchasing only"""
        profile = get_profile(request)
        if not profile or profile.role not in ('admin', 'purchasing'):
            return Response(status=status.HTTP_403_FORBIDDEN)

        flagged = TransferRequest.objects.filter(
            flagged_no_sale=True,
            status='fulfilled',
        ).select_related(
            'requesting_branch', 'source_branch', 'item', 'requested_by__user'
        ).order_by('-responded_at')

        return Response(
            TransferRequestListSerializer(flagged, many=True).data
        )

    # ── Analytics: frequently transferred items ───────────────────────────────
    @action(detail=False, methods=['get'], url_path='analytics')
    def analytics(self, request):
        """GET /api/transfers/analytics/ — purchasing + admin only"""
        profile = get_profile(request)
        if not profile or profile.role not in ('admin', 'purchasing'):
            return Response(status=status.HTTP_403_FORBIDDEN)

        from django.db.models import Count, Q
        from datetime import timedelta

        now = timezone.now()
        thirty_days_ago = now - timedelta(days=30)
        seven_days_ago = now - timedelta(days=7)

        # Items transferred most in last 30 days
        top_items = (
            TransferRequest.objects
            .filter(created_at__gte=thirty_days_ago)
            .exclude(status='cancelled')
            .values('item__id', 'item__name', 'item__softech_id')
            .annotate(request_count=Count('id'))
            .order_by('-request_count')[:10]
        )

        # Status breakdown this week
        weekly = (
            TransferRequest.objects
            .filter(created_at__gte=seven_days_ago)
            .values('status')
            .annotate(count=Count('id'))
        )

        # Rejection reason breakdown (last 30 days)
        rejections = (
            TransferRequest.objects
            .filter(created_at__gte=thirty_days_ago, status='rejected')
            .values('rejection_reason')
            .annotate(count=Count('id'))
        )

        # Most requesting branches (last 30 days)
        top_requestors = (
            TransferRequest.objects
            .filter(created_at__gte=thirty_days_ago)
            .exclude(status='cancelled')
            .values('requesting_branch__id', 'requesting_branch__name_ar')
            .annotate(count=Count('id'))
            .order_by('-count')[:6]
        )

        # Recommendation: items with ≥3 transfers in 30 days → add to order
        recommended_for_order = [
            item for item in top_items if item['request_count'] >= 3
        ]

        return Response({
            'top_items_last_30_days': list(top_items),
            'weekly_status_breakdown': list(weekly),
            'rejection_reasons': list(rejections),
            'top_requesting_branches': list(top_requestors),
            'recommended_for_regular_order': recommended_for_order,
            'flagged_count': TransferRequest.objects.filter(flagged_no_sale=True).count(),
        })
