// ── Replace the entire transfersApi block in frontend/src/api/client.js ──

export const transfersApi = {
  // CRUD
  list:    (params) => api.get('/transfers/', { params }),
  get:     (id)     => api.get(`/transfers/${id}/`),
  create:  (data)   => api.post('/transfers/', data),
  update:  (id, data) => api.patch(`/transfers/${id}/`, data),
  delete:  (id)     => api.delete(`/transfers/${id}/`),

  // State machine actions
  submit:     (id)         => api.post(`/transfers/${id}/submit/`),
  approve:    (id)         => api.post(`/transfers/${id}/approve/`),
  reject:     (id, data)   => api.post(`/transfers/${id}/reject/`, data),
  revision:   (id, data)   => api.post(`/transfers/${id}/revision/`, data),
  sendToERP:  (id, data)   => api.post(`/transfers/${id}/send-to-erp/`, data),
  complete:   (id)         => api.post(`/transfers/${id}/complete/`),
  cancel:     (id)         => api.post(`/transfers/${id}/cancel/`),

  // Item management
  addItem:    (id, data)   => api.post(`/transfers/${id}/items/`, data),
  removeItem: (id, itemId) => api.delete(`/transfers/${id}/items/${itemId}/`),
  updateItem: (id, itemId, data) => api.patch(`/transfers/${id}/items/${itemId}/`, data),

  // Chatter
  sendMessage: (id, data)  => api.post(`/transfers/${id}/messages/`, data),

  // Stock lookup
  itemStock:  (itemId)     => api.get('/transfers/item_stock/', { params: { item_id: itemId } }),
}
